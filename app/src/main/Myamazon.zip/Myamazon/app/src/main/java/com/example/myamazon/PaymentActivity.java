package com.example.myamazon;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myamazon.databinding.ActivityPaymentBinding;

import java.util.ArrayList;

public class PaymentActivity extends AppCompatActivity {
    ActivityPaymentBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate ( savedInstanceState );
        binding = ActivityPaymentBinding.inflate ( getLayoutInflater ( ) );
        setContentView ( binding.getRoot ( ) );
        Intent intent = getIntent ( );
        int q = intent.getIntExtra ( "q", -1 );
        int id = intent.getIntExtra ( "id", -1 );
        mySql mySql =new mySql ( this );
        ArrayList<Integer> product=new ArrayList<> (  );
        mySql.addProductsToCustomer ( id,product );
        if (q>5){

        }



    }
}