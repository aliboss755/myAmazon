package com.example.myamazon;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.myamazon.databinding.ActivityOrdringCartBinding;

import java.util.ArrayList;

public class Ordering_CartActivity extends AppCompatActivity implements OnItemClickListener {
    ActivityOrdringCartBinding binding;
    int productId;
    int customerId;
    mySql mySql;
    ArrayList<Product> products;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate ( savedInstanceState );
        binding = ActivityOrdringCartBinding.inflate ( getLayoutInflater ( ) );
        setContentView ( binding.getRoot ( ) );
        mySql = new mySql ( this );

        Intent intent = getIntent ( );
        String title = intent.getStringExtra ( "title" );
        double price = intent.getDoubleExtra ( "price", -1 );
        int quntity = intent.getIntExtra ( "quntity", -1 );
        String image = intent.getStringExtra ( "image" );
        productId = intent.getIntExtra ( "productId", -1 );
        customerId = intent.getIntExtra ( "customerId", -1 );
//        binding.productImage.setImageURI ( Uri.parse ( image ) );
//        binding.productName.setText ( title );
//        binding.productQuantities.setText ( String.valueOf ( quntity ) );
//        Toast.makeText ( this, productId+"", Toast.LENGTH_SHORT ).show ( );
//        Toast.makeText ( this, customerId+"", Toast.LENGTH_SHORT ).show ( );
        mySql.associateProductWithCustomer ( productId, customerId );
        products = ( ArrayList<Product> ) mySql.getProductsByCustomer2 ( customerId);
        ProductAdepter adepter = new ProductAdepter ( products, this );
        binding.productRv.setAdapter ( adepter );
        binding.productRv.setLayoutManager ( new GridLayoutManager ( this, 2, LinearLayoutManager.VERTICAL, false ) );
        binding.productRv.setHasFixedSize ( true );
//        binding.productPrice.setText ( String.valueOf ( price ) );
//        binding.productDeleted.setOnClickListener ( v -> {
//            binding.ParentCart.setVisibility ( View.GONE );
//        } );

    }

    @Override
    public void onItemClick(View view, int position, int id) {

    }

    @Override
    public void onDelete(int position, int id) {

    }
}