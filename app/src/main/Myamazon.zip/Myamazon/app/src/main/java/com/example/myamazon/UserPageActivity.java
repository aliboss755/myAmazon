package com.example.myamazon;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.myamazon.databinding.ActivityUserPageBinding;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.Objects;


public class UserPageActivity extends AppCompatActivity {
    ActivityUserPageBinding binding;
    mySql mySql;
    int id;
    BottomNavigationView navigationView;
    Customer customer;

    @SuppressLint("NonConstantResourceId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate ( savedInstanceState );
        binding = ActivityUserPageBinding.inflate ( getLayoutInflater ( ) );
        setContentView ( binding.getRoot ( ) );
        navigationView = (binding.toolbar);
        id = getIntent ( ).getIntExtra ( "id", -1 );
        mySql = new mySql ( this );
        mySql mySql = new mySql ( this );
        customer = mySql.getCustomer ( getIntent ( ).getIntExtra ( "id", -1 ) );
        Toast.makeText ( this, customer.getPassword ( ), Toast.LENGTH_SHORT ).show ( );
        binding.userNameEt.setText ( customer.getUserName ( ) );
        binding.PasswordEt.setText ( customer.getPassword ( ) );
        binding.EmileEt.setText ( customer.getEmail ( ) );
        binding.toolbar.setSelectedItemId ( R.id.details );
        Menu m = binding.toolbar.getMenu ( );
        MenuItem save = m.findItem ( R.id.details );
        MenuItem edit = m.findItem ( R.id.edit );
        MenuItem delete = m.findItem ( R.id.delete );
        edit.setVisible ( false );
        delete.setVisible ( false );
        save.setVisible ( false );
        binding.toolbar.setOnItemSelectedListener ( item -> {

            if (item.getItemId ( ) == R.id.details) {
                String name = Objects.requireNonNull ( binding.userNameEt.getText ( ) ).toString ( );
                String password = Objects.requireNonNull ( binding.PasswordEt.getText ( ) ).toString ( );
                String emile = Objects.requireNonNull ( binding.EmileEt.getText ( ) ).toString ( );
                mySql.updateCustomer ( customer.userName, name, password, emile );
                finish ( );
                return true;
            }
            return false;


        } );
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater ( ).inflate ( R.menu.details_menu, menu );
        MenuItem save = menu.findItem ( R.id.details );
        MenuItem edit = menu.findItem ( R.id.edit );
        MenuItem delete = menu.findItem ( R.id.delete );
        save.setVisible ( false );
        edit.setVisible ( true );
        delete.setVisible ( false );
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId ( ) == R.id.edit) {
            Menu m = binding.toolbar.getMenu ( );
            MenuItem save = m.findItem ( R.id.details );
            MenuItem edit = m.findItem ( R.id.edit );
            MenuItem delete = m.findItem ( R.id.delete );
            edit.setVisible ( false );
            delete.setVisible ( false );
            save.setVisible ( true );
        } else if (item.getItemId ( ) == R.id.details) {
            String name = Objects.requireNonNull ( binding.userNameEt.getText ( ) ).toString ( );
            String password = Objects.requireNonNull ( binding.PasswordEt.getText ( ) ).toString ( );
            String emile = Objects.requireNonNull ( binding.EmileEt.getText ( ) ).toString ( );
            mySql.updateCustomer ( customer.userName, name, password, emile );
            finish ( );
        }
        return true;
    }


}